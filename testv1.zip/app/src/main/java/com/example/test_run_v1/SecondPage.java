package com.example.test_run_v1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SecondPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.second_page);

        Button bgnr = findViewById(R.id.bgnr);
        bgnr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SecondPage.this,Mode.class);
                startActivity(intent);
            }
        });


        Button stdn = findViewById(R.id.stdn);
        stdn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SecondPage.this,Mode.class);
                startActivity(intent);
            }
        });

        Button prsn = findViewById(R.id.prsn);
        prsn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SecondPage.this,Mode.class);
                startActivity(intent);
            }
        });

    }

}
